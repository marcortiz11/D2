<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Front" tilewidth="32" tileheight="64" tilecount="2" columns="0">
 <tile id="1">
  <image width="32" height="64" source="SimpleColumn.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="63" source="ComplexColumn.PNG"/>
 </tile>
</tileset>
